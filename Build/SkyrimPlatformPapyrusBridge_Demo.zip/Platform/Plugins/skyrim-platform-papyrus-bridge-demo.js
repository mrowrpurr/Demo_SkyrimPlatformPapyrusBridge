var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
/* eslint-disable @typescript-eslint/adjacent-overload-signatures */
/* eslint-disable @typescript-eslint/no-namespace */
// Generated automatically. Do not edit.
System.register("Steam/steamapps/common/Skyrim Special Edition/Data/Platform/Modules/skyrimPlatform", [], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
        }
    };
});
System.register("Steam/steamapps/common/Skyrim Special Edition/Data/Platform/Modules/papyrusBridge", ["Steam/steamapps/common/Skyrim Special Edition/Data/Platform/Modules/skyrimPlatform"], function (exports_2, context_2) {
    "use strict";
    var skyrimPlatform_1, sp, skyrimPlatformBridgeEsp, skyrimPlatformBridgeMessagesContainerId, skyrimPlatformBridgeQuestId, skseModEventNamePrefix_ModEvent, skseModEventNamePrefix_GlobalEvent, skseModEventNamePrefix_Response, skyrimPlatformBridgeEventMessageDelimiter, messagePrefix_Event, messagePrefix_Request, messagePrefix_Response, skyrimPlatformBridgeJsonDataPrefix, skyrimPlatformBridgeConnectionRequestQueryName, skyrimPlatformBridgeConnectionRequestResponseText, messageTypePrefixes, SkseModEvent, PapyrusBridge, defaultInstance;
    var __moduleName = context_2 && context_2.id;
    function getVersion() {
        return '1.0';
    }
    exports_2("getVersion", getVersion);
    function log() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        skyrimPlatform_1.writeLogs('papyrusBridge', Date.now(), args);
    }
    function getConnection(connectionName) {
        return new PapyrusBridge(connectionName);
    }
    exports_2("getConnection", getConnection);
    function getPapyrusConnection(connectionName) {
        return new PapyrusBridge(connectionName);
    }
    exports_2("getPapyrusConnection", getPapyrusConnection);
    return {
        setters: [
            function (skyrimPlatform_1_1) {
                skyrimPlatform_1 = skyrimPlatform_1_1;
                sp = skyrimPlatform_1_1;
            }
        ],
        execute: function () {
            skyrimPlatformBridgeEsp = 'SkyrimPlatformBridge.esp';
            skyrimPlatformBridgeMessagesContainerId = 0xd66;
            skyrimPlatformBridgeQuestId = 0x800;
            skseModEventNamePrefix_ModEvent = 'SkyrimPlatformBridge_Event_'; // Target a particular mod
            skseModEventNamePrefix_GlobalEvent = 'SkyrimPlatformBridge_Event_'; // Globally subscribe/publish
            skseModEventNamePrefix_Response = 'SkyrimPlatformBridge_Response_'; // Reserved for Response/Reply management
            skyrimPlatformBridgeEventMessageDelimiter = '<||>';
            messagePrefix_Event = '::SKYRIM_PLATFORM_BRIDGE_EVENT::';
            messagePrefix_Request = '::SKYRIM_PLATFORM_BRIDGE_REQUEST::';
            messagePrefix_Response = '::SKYRIM_PLATFORM_BRIDGE_RESPONSE::';
            skyrimPlatformBridgeJsonDataPrefix = '::SKYRIM_PLATFORM_BRIDGE_JSON::';
            skyrimPlatformBridgeConnectionRequestQueryName = 'SkyrimPlatformBridge_ConnectionRequest'.toLowerCase();
            skyrimPlatformBridgeConnectionRequestResponseText = 'CONNECTED';
            messageTypePrefixes = new Map([
                [messagePrefix_Event, 'event'],
                [messagePrefix_Request, 'request'],
                [messagePrefix_Response, 'response']
            ]);
            // TODO
            SkseModEvent = /** @class */ (function () {
                function SkseModEvent() {
                }
                return SkseModEvent;
            }());
            exports_2("SkseModEvent", SkseModEvent);
            PapyrusBridge = /** @class */ (function () {
                function PapyrusBridge(connectionName) {
                    if (connectionName === void 0) { connectionName = ''; }
                    this.activeConnections = new Set();
                    this.connectionName = '';
                    this.messagesContainerFormId = 0;
                    this.questFormId = 0;
                    this.isConnected = false;
                    this.isListening = false;
                    this.requestCallbacks = new Array();
                    this.eventCallbacks = new Array();
                    this.connectionCallbacks = new Array();
                    this.requestResponsePromises = new Map();
                    this.connectionName = connectionName.toLowerCase();
                }
                PapyrusBridge.prototype.getConnection = function (connectionName) {
                    return new PapyrusBridge(connectionName.toLowerCase());
                };
                PapyrusBridge.prototype.getConnectionName = function () {
                    var _a;
                    return (_a = this.connectionName) === null || _a === void 0 ? void 0 : _a.toLowerCase();
                };
                PapyrusBridge.prototype.onRequest = function (callback) {
                    this.listen();
                    this.requestCallbacks.push(callback);
                };
                PapyrusBridge.prototype.onEvent = function (callback) {
                    this.listen();
                    this.eventCallbacks.push(callback);
                };
                PapyrusBridge.prototype.onConnected = function (callback) {
                    this.listen();
                    this.connectionCallbacks.push(callback);
                };
                PapyrusBridge.prototype.listen = function () {
                    var _this = this;
                    if (!this.isListening) {
                        this.isListening = true;
                        skyrimPlatform_1.on('containerChanged', function (changeInfo) {
                            var container = changeInfo.newContainer || changeInfo.oldContainer;
                            if (container) {
                                _this.setMessagesContainerFormId();
                                if (_this.messagesContainerFormId && _this.messagesContainerFormId == container.getFormID()) {
                                    var messageText = changeInfo.baseObj.getName();
                                    if (messageText) {
                                        var messageType = _this.getMessageType(messageText);
                                        if (messageType) {
                                            var message = _this.parse(messageType, messageText);
                                            if (message) {
                                                _this._onPapyrusMessage(messageType, message);
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                };
                PapyrusBridge.prototype.sendModEvent = function (skseModEventName, parameterBuilder) {
                    var _this = this;
                    skyrimPlatform_1.once('update', function () {
                        var quest = null;
                        if (!_this.questFormId) {
                            quest = skyrimPlatform_1.Game.getFormFromFile(skyrimPlatformBridgeQuestId, skyrimPlatformBridgeEsp);
                            if (quest) {
                                _this.questFormId = quest.getFormID();
                            }
                        }
                        if (!quest) {
                            // Todo: cache object (and *handle stale errors*)
                            quest = skyrimPlatform_1.Game.getFormFromFile(skyrimPlatformBridgeQuestId, skyrimPlatformBridgeEsp);
                        }
                        if (quest) {
                            var handle = sp.ModEvent.create(skseModEventName);
                            if (handle) {
                                var modEvent = sp.ModEvent;
                                var handle_1 = modEvent.Create(skseModEventName);
                                parameterBuilder(modEvent, handle_1);
                                modEvent.send(handle_1);
                            }
                        }
                        else {
                            log("Could not send message, Quest object " + skyrimPlatformBridgeQuestId.toString(16) + " not found.");
                        }
                    });
                };
                PapyrusBridge.prototype.send = function (eventName, data, target, source) {
                    this.sendEvent({ eventName: eventName, data: data, target: target, source: source });
                };
                PapyrusBridge.prototype.sendEvent = function (event) {
                    var messageToSend = this._prepareMessageForSending('event', event);
                    if (messageToSend) {
                        this.sendModEvent(messageToSend.skseModEventName, function (modEvent, handle) {
                            modEvent.pushString(handle, messageToSend.messageType);
                            modEvent.pushString(handle, messageToSend.eventNameOrQuery);
                            modEvent.pushString(handle, messageToSend.source);
                            modEvent.pushString(handle, messageToSend.target);
                            modEvent.pushString(handle, messageToSend.dataText);
                            modEvent.pushString(handle, messageToSend.replyId);
                        });
                    }
                };
                PapyrusBridge.prototype.request = function (query, data, target, source) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            return [2 /*return*/, this.makeRequest({
                                    query: query, data: data, target: target, source: source
                                })];
                        });
                    });
                };
                PapyrusBridge.prototype.makeRequest = function (request) {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        return __generator(this, function (_a) {
                            return [2 /*return*/, new Promise(function (resolve) {
                                    try {
                                        var messageToSend_1 = _this._prepareMessageForSending('request', request);
                                        if (messageToSend_1) {
                                            if (!messageToSend_1.replyId)
                                                messageToSend_1.replyId = _this.getUniqueReplyId();
                                            _this.requestResponsePromises.set(messageToSend_1.replyId, resolve);
                                            _this.sendModEvent(messageToSend_1.skseModEventName, function (modEvent, handle) {
                                                modEvent.pushString(handle, messageToSend_1.messageType);
                                                modEvent.pushString(handle, messageToSend_1.eventNameOrQuery);
                                                modEvent.pushString(handle, messageToSend_1.source);
                                                modEvent.pushString(handle, messageToSend_1.target);
                                                modEvent.pushString(handle, messageToSend_1.dataText);
                                                modEvent.pushString(handle, messageToSend_1.replyId);
                                            });
                                        }
                                        else {
                                            resolve(undefined);
                                        }
                                    }
                                    catch (_a) {
                                        resolve(undefined);
                                    }
                                })];
                        });
                    });
                };
                PapyrusBridge.prototype._sendResponse = function (response) {
                    var messageToSend = this._prepareMessageForSending('response', response);
                    if (messageToSend) {
                        this.sendModEvent(messageToSend.skseModEventName, function (modEvent, handle) {
                            modEvent.pushString(handle, messageToSend.replyId);
                            modEvent.pushString(handle, messageToSend.dataText);
                        });
                    }
                };
                PapyrusBridge.prototype._prepareMessageForSending = function (messageType, message) {
                    var _a, _b, _c, _d;
                    skyrimPlatform_1.once('update', function () {
                        skyrimPlatform_1.printConsole("PREPARE MESSAGE " + messageType);
                        skyrimPlatform_1.printConsole(message.target);
                        skyrimPlatform_1.printConsole(JSON.stringify(message));
                    });
                    var target = (_b = (_a = message.target) !== null && _a !== void 0 ? _a : this.connectionName) !== null && _b !== void 0 ? _b : '';
                    if (!target) {
                        skyrimPlatform_1.once('update', function () {
                            skyrimPlatform_1.printConsole("[PapyrusBridge] Tried sending event to null target " + JSON.stringify(message));
                        });
                        return;
                    }
                    var source = (_d = (_c = message.source) !== null && _c !== void 0 ? _c : this.connectionName) !== null && _d !== void 0 ? _d : '';
                    var data;
                    switch (messageType) {
                        case 'event': {
                            data = message.data;
                            break;
                        }
                        case 'request': {
                            data = message.data;
                            break;
                        }
                        case 'response': {
                            data = message.data;
                            break;
                        }
                    }
                    var dataText = '';
                    if (typeof data === 'string')
                        dataText = data.toString();
                    else if (data === undefined)
                        dataText = '';
                    else
                        dataText = "" + skyrimPlatformBridgeJsonDataPrefix + JSON.stringify(data);
                    var eventNameOrQuery = '';
                    switch (messageType) {
                        case 'event': {
                            eventNameOrQuery = message.eventName;
                            break;
                        }
                        case 'request': {
                            eventNameOrQuery = message.query;
                            break;
                        }
                    }
                    var skseModEventName = "" + skseModEventNamePrefix_ModEvent + target;
                    if (messageType == 'response')
                        skseModEventName = "" + skseModEventNamePrefix_Response + message.replyId;
                    return { skseModEventName: skseModEventName, messageType: messageType, eventNameOrQuery: eventNameOrQuery, source: source, target: target, dataText: dataText, replyId: message.replyId };
                };
                PapyrusBridge.prototype.parse = function (messageType, message) {
                    var eventParts = message.split(skyrimPlatformBridgeEventMessageDelimiter);
                    if (eventParts.length < 4)
                        return;
                    switch (messageType) {
                        case 'event': {
                            return { eventName: eventParts[1].toLowerCase(), source: eventParts[2].toLowerCase(), target: eventParts[3].toLowerCase(), data: eventParts.slice(5).join('||') };
                        }
                        case 'request': {
                            return { query: eventParts[1].toLowerCase(), source: eventParts[2].toLowerCase(), target: eventParts[3].toLowerCase(), replyId: eventParts[4].toLowerCase(), data: eventParts.slice(5).join('||') };
                        }
                        case 'response': {
                            return { source: eventParts[2].toLowerCase(), target: eventParts[3].toLowerCase(), replyId: eventParts[4].toLowerCase(), data: eventParts.slice(5).join('||') };
                        }
                    }
                };
                PapyrusBridge.prototype.getMessageType = function (receivedText) {
                    var messageType;
                    messageTypePrefixes.forEach(function (type, prefix) {
                        if (receivedText.startsWith(prefix)) {
                            messageType = type;
                        }
                    });
                    return messageType;
                };
                PapyrusBridge.prototype.getUniqueReplyId = function () {
                    return Math.random() + "_" + Math.random();
                };
                PapyrusBridge.prototype._onPapyrusMessage = function (messageType, message) {
                    switch (messageType) {
                        case 'event': {
                            this._onEvent(message);
                            break;
                        }
                        case 'request': {
                            this._onRequest(message);
                            break;
                        }
                        case 'response': {
                            this._onResponse(message);
                            break;
                        }
                    }
                };
                PapyrusBridge.prototype._onEvent = function (event) {
                    this.eventCallbacks.forEach(function (callback) { return callback(event); });
                };
                PapyrusBridge.prototype._onRequest = function (request) {
                    var _this = this;
                    if (request.query == skyrimPlatformBridgeConnectionRequestQueryName) {
                        this._onConnectedRequest(request);
                    }
                    else {
                        this.requestCallbacks.forEach(function (callback) {
                            callback(request, function (data) {
                                var _a;
                                _this._sendResponse({
                                    replyId: request.replyId,
                                    target: request.source,
                                    source: (_a = _this.connectionName) !== null && _a !== void 0 ? _a : '',
                                    data: data
                                });
                            });
                        });
                    }
                };
                PapyrusBridge.prototype._onConnectedRequest = function (request) {
                    if ((!this.connectionName) || this.connectionName == request.source) {
                        this._sendResponse({ data: skyrimPlatformBridgeConnectionRequestResponseText, replyId: request.replyId, source: this.connectionName, target: request.source });
                        if (this.connectionName && !this.isConnected) {
                            this.isConnected = true;
                        }
                        if (!this.activeConnections.has(request.source)) {
                            this.activeConnections.add(request.source);
                            this.connectionCallbacks.forEach(function (callback) { return callback(request.source); });
                        }
                    }
                };
                PapyrusBridge.prototype._onResponse = function (response) {
                    if (response.replyId) {
                        if (this.requestResponsePromises.has(response.replyId)) {
                            this.requestResponsePromises.get(response.replyId)(response);
                            this.requestResponsePromises.delete(response.replyId);
                        }
                    }
                };
                PapyrusBridge.prototype.setMessagesContainerFormId = function () {
                    if (!this.messagesContainerFormId) {
                        var messagesContainer = skyrimPlatform_1.Game.getFormFromFile(skyrimPlatformBridgeMessagesContainerId, skyrimPlatformBridgeEsp);
                        if (messagesContainer) {
                            this.messagesContainerFormId = messagesContainer.getFormID();
                        }
                    }
                };
                return PapyrusBridge;
            }());
            exports_2("PapyrusBridge", PapyrusBridge);
            defaultInstance = new PapyrusBridge();
            exports_2("default", defaultInstance);
        }
    };
});
System.register("Users/mrowr/Dropbox/Skyrim/Mods/PapyruSP/Plugin/index", ["Steam/steamapps/common/Skyrim Special Edition/Data/Platform/Modules/papyrusBridge", "Steam/steamapps/common/Skyrim Special Edition/Data/Platform/Modules/skyrimPlatform"], function (exports_3, context_3) {
    "use strict";
    var papyrusBridge_1, skyrimPlatform_2, connection1, connection2;
    var __moduleName = context_3 && context_3.id;
    return {
        setters: [
            function (papyrusBridge_1_1) {
                papyrusBridge_1 = papyrusBridge_1_1;
            },
            function (skyrimPlatform_2_1) {
                skyrimPlatform_2 = skyrimPlatform_2_1;
            }
        ],
        execute: function () {
            // Standard usage: manage specific connections
            connection1 = papyrusBridge_1.getConnection('PapyruSP_Connection1');
            connection2 = papyrusBridge_1.getConnection('PapyruSP_Connection2');
            connection1.onConnected(function (source) {
                skyrimPlatform_2.Debug.messageBox("[SP Connection 1] onConnected " + JSON.stringify(source));
            });
            connection2.onConnected(function (source) {
                skyrimPlatform_2.Debug.messageBox("[SP Connection 2] onConnected " + JSON.stringify(source));
            });
            connection1.onEvent(function (event) {
                skyrimPlatform_2.Debug.messageBox("[SP Connection 1] onEvent " + JSON.stringify(event));
            });
            connection2.onEvent(function (event) {
                skyrimPlatform_2.Debug.messageBox("[SP Connection 2] onEvent " + JSON.stringify(event));
            });
            connection1.onRequest(function (request, reply) {
                reply("[SP Connection 1] Reply to " + JSON.stringify(request));
            });
            connection2.onRequest(function (request, reply) {
                reply("[SP Connection 1] Reply to " + JSON.stringify(request));
            });
            // Advanced usage: listen for events globally
            papyrusBridge_1.default.onConnected(function (source) {
                skyrimPlatform_2.once('update', function () {
                    skyrimPlatform_2.Debug.messageBox("**[OnConnected] " + JSON.stringify(source));
                });
            });
            papyrusBridge_1.default.onEvent(function (event) {
                skyrimPlatform_2.once('update', function () {
                    skyrimPlatform_2.Debug.messageBox("**[OnEvent] " + JSON.stringify(event));
                });
            });
            papyrusBridge_1.default.onRequest(function (request) {
                skyrimPlatform_2.once('update', function () {
                    skyrimPlatform_2.Debug.messageBox("**[OnRequest] " + JSON.stringify(request));
                });
            });
        }
    };
});
